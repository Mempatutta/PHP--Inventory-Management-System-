<?php include('header.php'); ?>
<?php include('css.php'); ?>
<?php
	session_start();
	
	if (isset($_SESSION['id'])){
		$query=mysqli_query($conn,"SELECT * FROM user 
								WHERE user_ID='".$_SESSION['id']."'");
		$row=mysqli_fetch_array($query);
		
		if ($row['access']==1){
			header('location:admin/');
		}
		elseif ($row['access']==2){
			header('location:supplier/');
		}
		else{
			header('location:customer/');
		}
	}
?>
<body>
<div class="container">
	<div id="login_form" class="well">
		<h2><center><span class="glyphicon glyphicon-lock"></span>Login Page</center></h2>
		<hr>
		<form method="POST" action="login.php">
		User Name: <input type="text" name="username" class="form-control" required>
		<div style="height: 10px;"></div>		
		Password: <input type="password" name="password" class="form-control" required> 
		<div style="height: 10px;"></div>
		<center><button  type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-log-in"></span> Login</button></center>
		</form>
		<div style="height: 15px;"></div>
		<div style="color: red; font-size: 15px;">
			<center>
			<?php
				
				if(isset($_SESSION['msg'])){
					echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				}
			?>
			</center>
		</div>
	</div>
</div>

</body>
</html>