<?php

	include('session.php');
	$product_id=mysqli_real_escape_string($conn,$_GET['id']);
	
	delete_product($conn,$product_id);
	function delete_product($conn,$product_id) {
		  
		$stmt = $conn->prepare("DELETE FROM product 
							WHERE product_ID=?");
	$stmt->bind_param('i',$product_id);
	$stmt->execute();
	$stmt->close();
		return $stmt;
	}
	header('location:product.php');

?>