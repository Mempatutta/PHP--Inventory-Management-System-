<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div id="wrapper">
<?php include('navbar.php'); ?>
	<div style="height:50px;"></div>
		<div id="page-wrapper">
			<div class="container-fluid">
				<p> Welcome, this is an online warehouse. We purchase products from suppliers, and then sell to stores.  </p>
	<div style="height:40px;"></div>
	<img src="../picture/warehouse.jpg" class="thumbnail" style="height:430px; width:1030px;">
	</div>
</div>
</div>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
</body>
</html>