<?php

	include('session.php');
	
	$id=mysqli_real_escape_string($conn,$_GET['id']);
	
	
	delete_user($conn,$id);
	
	function delete_user($conn,$id) {
		  
		$stmt = $conn->prepare("DELETE FROM user WHERE user_ID=?");
	$stmt->bind_param('i',$id);
	$stmt->execute();
	$stmt->close();
		return $stmt;
	}
	delete_supplier($conn,$id);
	
	function delete_supplier($conn,$id) {
		  
		$stmt = $conn->prepare("DELETE FROM supplier WHERE user_ID=?");
	$stmt->bind_param('i',$id);
	$stmt->execute();
	$stmt->close();
		return $stmt;
	}
	header('location:supplier.php');

?>