<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div id="wrapper">
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
<?php include('modal_add.php'); ?>
<script src="methods.js"></script>
<div style="height:50px;"></div>
<div id="page-wrapper">
<div class="container-fluid">
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Sales Report</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <table width="100%" class="table table-striped table-bordered table-hover" id="salesTable">
                <thead>
                    <tr>
						<th class="hidden"></th>
                        <th>Sales Date</th>
						<th>Customer</th>
                        <th>Total Purchase</th>
						<th>Action</th>
                    </tr>
                </thead>
                <tbody>
				<?php
					$sale=mysqli_query($conn,"SELECT * FROM sales 
					JOIN customer ON customer.user_ID=sales.user_ID 
					ORDER BY sales_date DESC");
					while($s_row=mysqli_fetch_array($sale)){
					?>
						<tr>
							<td class="hidden"></td>
							<td><?php echo date('M d, Y h:i A',strtotime($s_row['sales_date'])); ?></td>
							<td><?php echo $s_row['customer_name']; ?></td>
							<td align="right"><?php echo number_format($s_row['sales_total'],2); ?></td>
							<td>
								<a href="#detail<?php echo $s_row['sales_ID']; ?>" data-toggle="modal" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-fullscreen"></span> View Full Details</a>
								<?php include ('full_details.php'); ?>
							</td>
						</tr>
					<?php
					}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>

</body>
</html>