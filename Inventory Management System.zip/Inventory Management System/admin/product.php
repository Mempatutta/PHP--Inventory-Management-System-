<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div id="wrapper">
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
<?php include('modal_add.php'); ?>
<script src="methods.js"></script>
<div style="height:50px;"></div>
<div id="page-wrapper">
<div class="container-fluid">
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Products
				<span class="pull-right">
					<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addproduct"><i class="fa fa-plus-circle"></i> Add Product</button>
				</span>
			</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <table width="100%" class="table table-striped table-bordered table-hover" id="prodTable">
                <thead>
                    <tr>
                        <th>Product Name</th>
						<th>Category Name</th>
						<th>Supplier</th>
                        <th>Price</th>
						<th>Quantity</th>
						<th>Picture</th>
						<th>Action</th>
                    </tr>
                </thead>
                <tbody>
				<?php
					$prdct=mysqli_query($conn,"SELECT * FROM product 
					left JOIN category ON category.category_ID=product.category_ID 
					left JOIN supplier ON supplier.user_ID=product.supplier_ID");
					while($prdct_row=mysqli_fetch_array($prdct)){
						$product_id=$prdct_row['product_ID'];
					?>
				
						<tr>
							<td><?php echo $prdct_row['product_name']; ?></td>
					
							<td><?php echo $prdct_row['category_name']; ?></td>
							<td><?php echo $prdct_row['supplier_name']; ?></td>
							<td><?php echo $prdct_row['product_price']; ?></td>
							<td><?php echo $prdct_row['product_qty']; ?></td>
							<td><img src="../<?php 
							($prdct_row['picture'])? print $prdct_row['picture']:print "picture/noImage2.jpg"; 
							?>
							" height="50px" width="50px;"></td>
							<td>
								<button class="btn btn-success btn-sm" data-toggle="modal" data-target="#editprod_<?php echo $product_id; ?>"><i class="fa fa-edit"></i> Edit</button>
								<button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delproduct_<?php echo $product_id; ?>"><i class="fa fa-trash"></i> Delete</button>
								<?php include('modal_product.php'); ?>
							</td>
						</tr>
					<?php
					}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>

</body>
</html>