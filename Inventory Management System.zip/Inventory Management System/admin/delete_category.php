<?php

	include('session.php');
	$category_id=mysqli_real_escape_string($conn,$_GET['id']);
	
	delete_category($conn,$category_id);
	function delete_category($conn,$category_id) {
		  
		$stmt = $conn->prepare("DELETE FROM category 
							WHERE category_ID=?");
	$stmt->bind_param('i',$category_id);
	$stmt->execute();
	$stmt->close();
		return $stmt;
	}
	header('location:category.php');

?>