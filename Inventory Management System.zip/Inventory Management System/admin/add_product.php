<?php
	include('session.php');
	
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$supplier=mysqli_real_escape_string($conn,$_POST['supplier']);
	$category=mysqli_real_escape_string($conn,$_POST['category']);
	$price=mysqli_real_escape_string($conn,$_POST['price']);
	$qty=mysqli_real_escape_string($conn,$_POST['qty']);
	
	
	
	$path = PATHINFO($_FILES["image"]["name"]);
	
	if (empty($_FILES["image"]["name"])){
		$location="";
	}
	else{
		if ($path['extension'] == "png" OR $path['extension'] == "jpg") {
			$newProduct = $path['filename'] . "_" . time() . "." . $path['extension'];
			move_uploaded_file($_FILES["image"]["tmp_name"], "../picture/" . $newProduct);
			$location = "picture/" . $newProduct;
		}
		else{
			$location="";
			?>
				<script>
					window.alert('Picture not added!');
				</script>
			<?php
		}
	}
	
	
	insert_product($conn, $name,$category,$price,$qty,$location);
	
	function insert_product($conn,$name,$category,$price,$qty,$location){
		  
		mysqli_query($conn,"INSERT INTO product 
	(product_name,category_ID,product_price,product_qty,
				picture, supplier_ID) 
	values ('$name','$category','$price','$qty',
			'$location', '".$_SESSION['id']."')");
	}
	
	$ap="Add Product";
	$product_id=mysqli_insert_id($conn);
	$stmt = $conn->prepare("INSERT INTO inventory 
		(user_ID, action, product_ID, quantity, inventory_date) 
		VALUES (?,?,?,?,NOW())");
	$stmt->bind_param('isii', $id, $ap, $product_id, $qty);
	$stmt->execute();
	$stmt->close();
	?>
		<script>
			window.alert('Success, product added!');
			window.history.back();
		</script>
