<?php

	require_once('session.php');
	
	$id=mysqli_real_escape_string($conn,$_GET['id']);
	
	$username=mysqli_real_escape_string($conn,$_POST['username']);
	$password=mysqli_real_escape_string($conn,$_POST['password']);
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$address=mysqli_real_escape_string($conn,$_POST['address']);
	$contact=mysqli_real_escape_string($conn,$_POST['contact']);
	
	$a=mysqli_query($conn,"SELECT * FROM user WHERE user_ID='id'");
	$row=mysqli_fetch_array($a);
	
	$password==$row['password']? $pswd=$password:$pswd=sha1($password);
	
	
	edit_user($conn,$username, $pswd ,$id);
	function edit_user($conn,$username, $pswd ,$id) {
		  
		$stmt = $conn->prepare("UPDATE user 
	 SET username=?, password=?
	 WHERE user_ID=?");
    $stmt->bind_param('ssi', $username, $pswd ,$id);
    $stmt->execute();
	$stmt->close();
		return $stmt;
	}
	
	
	edit_supplier($conn,$name, $address,$contact ,$id);
	function edit_supplier($conn,$name, $address,$contact ,$id) {
		  
	$stmt = $conn->prepare("UPDATE supplier 
						SET supplier_name=?, address=?, contact=?
						WHERE user_ID=?");
    $stmt->bind_param('sssi', $name, $address,$contact ,$id);
    $stmt->execute();
	$stmt->close();
		return $stmt;
	}
	?>
		<script>
			window.alert('Success, supplier updated!');
			window.history.back();
		</script>
	<?php

?>