<?php

	include('session.php');
	
	$id=mysqli_real_escape_string($conn,$_GET['id']);
	
	$cat_name=mysqli_real_escape_string($conn,$_POST['name']);
	
	
	
	edit_category($conn,$cat_name ,$id);
	function edit_category($conn,$cat_name ,$id) {
		  
		$stmt = $conn->prepare("UPDATE category 
	 SET category_name=?
	 WHERE category_ID=?");
    $stmt->bind_param('si', $cat_name ,$id);
    $stmt->execute();
	$stmt->close();
		return $stmt;
	}
	
	
	?>
		<script>
			window.alert('Success, category updated!');
			window.history.back();
		</script>
	<?php

?>