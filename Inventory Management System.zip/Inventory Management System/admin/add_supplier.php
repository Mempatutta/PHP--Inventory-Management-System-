<?php
	include('session.php');
	
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$username=mysqli_real_escape_string($conn,$_POST['username']);
	$address=mysqli_real_escape_string($conn,$_POST['address']);
	$contact=mysqli_real_escape_string($conn,$_POST['contact']);
	$password=mysqli_real_escape_string($conn,(sha1($_POST['password'])));
	
	
	$stmt = $conn->prepare("INSERT INTO user
	(username ,password, access) 
	VALUES (?,?,?)");
	$a=2;
	$stmt->bind_param('ssi',$username, $password, $a);
	$stmt->execute();
	$stmt->close();
	
	$id=mysqli_insert_id($conn);
	$stmt = $conn->prepare("INSERT INTO supplier
	(user_ID, supplier_name, address, contact) 
	VALUES (?,?,?,?)");
	$stmt->bind_param('isss',$id, $name, $address, $contact);
	$stmt->execute();
	$stmt->close();
	?>
		<script>
			window.alert('Success, supplier added!');
			window.history.back();
		</script>
