

<!-- Add Customer -->
    <div class="modal fade" id="addcustomer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New Customer</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
                    <form role="form" method="POST" action="add_customer.php" enctype="multipart/form-data">
						<div class="container-fluid">
						<div style="height:20px;"></div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Name:</span>
                            <input type="text" style="width:350px; text-transform:capitalize;" class="form-control" name="name" required>
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Username:</span>
                            <input type="text" style="width:350px;" class="form-control" name="username" required>
                        </div>
						
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Phone:</span>
                            <input type="text" style="width:350px;" class="form-control" name="contact">
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Address:</span>
                            <input type="text" style="width:350px; text-transform:capitalize;" class="form-control" name="address">
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Password:</span>
                            <input type="password" style="width:350px;" class="form-control" name="password" required>
                        </div>  						
						</div>
				</div>
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
					</form>
                </div>
			</div>
		</div>
    </div>
<!-- /.modal -->

<!-- Add Supplier -->
    <div class="modal fade" id="addsupplier" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New Supplier</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
                    <form role="form" method="POST" action="add_supplier.php" enctype="multipart/form-data">
						<div class="container-fluid">
						<div style="height:20px;"></div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Supplier Name:</span>
                            <input type="text" style="width:330px; text-transform:capitalize;" class="form-control" name="name" required>
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Username:</span>
                            <input type="text" style="width:350px;" class="form-control" name="username" required>
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Phone:</span>
                            <input type="text" style="width:350px;" class="form-control" name="contact">
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Address:</span>
                            <input type="text" style="width:350px; text-transform:capitalize;" class="form-control" name="address">
                        </div>
						
						
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Password:</span>
                            <input type="password" style="width:350px;" class="form-control" name="password" required>
                        </div>  						
						</div>
				</div>
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
					</form>
                </div>
			</div>
		</div>
    </div>
<!-- /.modal -->

<!-- Add Category -->
    <div class="modal fade" id="addCategory" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New Category</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
                    <form role="form" method="POST" action="add_category.php" enctype="multipart/form-data">
						<div class="container-fluid">
						<div style="height:20px;"></div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Category Name:</span>
                            <input type="text" style="width:330px; text-transform:capitalize;" class="form-control" name="name" required>
                        </div>
												
						</div>
				</div>
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
					</form>
                </div>
			</div>
		</div>
    </div>
<!-- /.modal -->

<!-- Add Product -->
    <div class="modal fade" id="addproduct" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New Product</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
                    <form role="form" method="POST" action="add_product.php" enctype="multipart/form-data">
						<div class="container-fluid">
						<div style="height:20px;"></div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Name:</span>
                            <input type="text" style="width:350px; text-transform:capitalize;" class="form-control" name="name" required>
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Category:</span>
                            <select style="width:350px;" class="form-control" name="category">
								<?php
									$category=mysqli_query($conn,"SELECT * FROM category");
									while($row=mysqli_fetch_array($category)){
										?>
											<option value="<?php echo $row['category_ID']; ?>"><?php echo $row['category_name']; ?></option>
										<?php
									}
								?>
							</select>
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Supplier:</span>
                            <select style="width:350px;" class="form-control" name="supplier">
								<?php
									$supplier=mysqli_query($conn,"SELECT * FROM supplier");
									while($supplier_row=mysqli_fetch_array($supplier)){
										?>
											<option value="<?php echo $supplier_row['user_ID']; ?>"><?php echo $supplier_row['supplier_name']; ?></option>
										<?php
									}
								?>
							</select>
                        </div>
                        <div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Price:</span>
                            <input type="text" style="width:350px;" class="form-control" name="price" required>
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Quantity:</span>
                            <input type="text" style="width:350px;" class="form-control" name="qty">
                        </div>
						<div class="form-group input-group">
                            <span style="width:100px;" class="input-group-addon">Picture:</span>
                            <input type="file" style="width:350px;" class="form-control" name="image">
                        </div>            
						</div>
				</div>
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
					</form>
                </div>
			</div>
		</div>
    </div>
<!-- /.modal -->