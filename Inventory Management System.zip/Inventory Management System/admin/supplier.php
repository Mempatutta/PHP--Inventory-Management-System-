<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div id="wrapper">
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
<?php include('modal_add.php'); ?>
<script src="methods.js"></script>
<div style="height:50px;"></div>
<div id="page-wrapper">
<div class="container-fluid">
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Suppliers
				<span class="pull-right">
					<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addsupplier"><i class="fa fa-plus-circle"></i> Add Supplier</button>
				</span>
			</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <table width="100%" class="table table-striped table-bordered table-hover" id="supTable">
                <thead>
                    <tr>
                        <th>Supplier Name</th>
                        <th>Username</th>
                        <th>Phone</th>
						<th>Address</th>
                        <th>Password</th>
						<th>Action</th>
                    </tr>
                </thead>
                <tbody>
				<?php
					$supplier=mysqli_query($conn,"SELECT * FROM supplier 
												JOIN user 
												ON user.user_ID=supplier.user_ID");
					while($supplier_row=mysqli_fetch_array($supplier)){
					?>
						<tr>
							<td><?php echo $supplier_row['supplier_name']; ?></td>
							<td><?php echo $supplier_row['username']; ?></td>
							<td><?php echo $supplier_row['contact']; ?></td>
							<td><?php echo $supplier_row['address']; ?></td>
							<td>*****</td>
							<td>
								<button class="btn btn-success btn-sm" data-toggle="modal" data-target="#edit_<?php echo $supplier_row['user_ID']; ?>"><i class="fa fa-edit"></i> Edit</button>
								<button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#del_<?php echo $supplier_row['user_ID']; ?>"><i class="fa fa-trash"></i> Delete</button>
								<?php include('modal_supplier.php'); ?>
							</td>
						</tr>
					<?php
					}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>

</body>
</html>