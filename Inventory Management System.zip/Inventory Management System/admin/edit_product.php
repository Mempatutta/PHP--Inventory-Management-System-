<?php
	
	
	include('session.php');
	$id=mysqli_real_escape_string($conn,$_GET['id']);
	
	$a=mysqli_query($conn,"SELECT * FROM product WHERE product_ID='$id'");
	$b=mysqli_fetch_array($a);
	
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$price=mysqli_real_escape_string($conn,$_POST['price']);
	$qty=mysqli_real_escape_string($conn,$_POST['qty']);
	$category=mysqli_real_escape_string($conn,$_POST['category']);
	$supplier=mysqli_real_escape_string($conn,$_POST['supplier']);
	
	$path = PATHINFO($_FILES["image"]["name"]);
	
	if (empty($_FILES["image"]["name"])){
		$location=$b['picture'];
	}
	else{
		if ($path['extension'] == "png" OR $path['extension'] == "jpg") {
			$newFile = $path['filename'] . "_" . time() . "." . $path['extension'];
			move_uploaded_file($_FILES["image"]["tmp_name"], "../picture/" . $newFile);
			$location = "picture/" . $newFile;
		}
		else{
			$location=$b['picture'];
			?>
				<script>
					window.alert('Picture not updated.');
				</script>
			<?php
		}
	}
	
	edit_product($conn,$name, $supplier,$category, 
								$price, $location, $qty ,$id);
	function edit_product($conn,$name, $supplier,$category, 
								$price, $location, $qty ,$id) {
		  
		$stmt = $conn->prepare("UPDATE product 
	 SET product_name=?, supplier_ID=?,category_ID=?, product_price=?, 
	 picture=?, product_qty=? 
	 WHERE product_ID=?");
    $stmt->bind_param('siidsdi', $name, $supplier,$category, 
								$price, $location, $qty ,$id);
    $stmt->execute();
	$stmt->close();
		return $stmt;
	}
	
	$stmt = $conn->prepare("insert into inventory
	(user_ID ,action, product_ID, quantity, inventory_date) 
	VALUES (?,?,?,?,NOW())");
	$ep="Edit Product";
	
	$stmt->bind_param('isid',$_SESSION['id'], $ep, $id, $qty);

	$stmt->execute();
	$stmt->close();
	
	
	?>
		<script>
			window.alert('Success, product updated!');
			window.history.back();
		</script>
	<?php

?>