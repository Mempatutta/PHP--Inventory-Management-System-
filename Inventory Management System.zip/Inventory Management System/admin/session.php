<?php

	session_start();
	
	if (!isset($_SESSION['id']) ||(trim ($_SESSION['id']) == '')) {
	header('location:../index.php');
    exit();
	}
	
	include('../conn.php');

	$u=mysqli_query($conn,"SELECT * FROM user 
							WHERE user_ID='".$_SESSION['id']."'");
	$row=mysqli_fetch_array($u);
	
	$user=$row['username'];
?>