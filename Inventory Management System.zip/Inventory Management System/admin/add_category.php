<?php
	include('session.php');
	
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	
	
	$category_id=mysqli_insert_id($conn);
	$stmt = $conn->prepare("INSERT INTO category 
		(category_ID, category_name) 
		VALUES (?,?)");
	$stmt->bind_param('is', $category_id, $name);
	$stmt->execute();
	$stmt->close();
	?>
		<script>
			window.alert('Success, category added!');
			window.history.back();
		</script>
