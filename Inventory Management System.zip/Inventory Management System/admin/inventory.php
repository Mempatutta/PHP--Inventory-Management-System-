<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div id="wrapper">
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
<?php include('modal_add.php'); ?>
<script src="methods.js"></script>
<div style="height:50px;"></div>
<div id="page-wrapper">
<div class="container-fluid">
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Inventory Report</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <table width="100%" class="table table-striped table-bordered table-hover" id="invTable">
                <thead>
                    <tr>
						<th class="hidden"></th>
                        <th>Date</th>
						<th>Product Name</th>
                        <th>User</th>
						<th>Quantity</th>
						<th>Action</th>
						
                    </tr>
                </thead>
                <tbody>
				<?php
					$inv=mysqli_query($conn,"SELECT * FROM inventory 
					JOIN product ON product.product_ID=inventory.product_ID 
					ORDER BY inventory_date DESC");
					while($inv_row=mysqli_fetch_array($inv)){
					?>
						<tr>
							<td class="hidden"></td>
							<td><?php echo date('M d, Y h:i A',strtotime($inv_row['inventory_date'])); ?></td>
							<td align="right"><?php echo $inv_row['product_name']; ?></td>
							<td>
							<?php 
								$user=mysqli_query($conn,"SELECT * FROM `user` 
								LEFT JOIN customer ON customer.user_ID=user.user_ID 
								LEFT JOIN supplier ON supplier.user_ID=user.user_ID 
								WHERE user.user_ID='".$inv_row['user_ID']."'");
								$user_row=mysqli_fetch_array($user);
								if($user_row['access']==1){
									echo "Admin";
								}
								elseif($user_row['access']==2){
									echo $user_row['customer_name'];
								}
								else{
									echo $user_row['supplier_name'];
								}
							?>
							</td>
							<td align="right"><?php echo $inv_row['quantity']; ?></td>
							<td align="right"><?php echo $inv_row['action']; ?></td>
							
							
						</tr>
					<?php
					}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>

</body>
</html>