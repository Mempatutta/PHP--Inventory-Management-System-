-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2019 at 12:23 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_ID` int(20) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_ID`, `admin_name`, `address`, `contact`) VALUES
(1, 'Adam21', '808 Street, Van21', 'adam21@hotmail.com'),
(1, 'Adam21', '808 Street, Van21', 'adam21@hotmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_ID` int(20) NOT NULL,
  `user_ID` int(20) NOT NULL,
  `product_ID` int(20) NOT NULL,
  `qty` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_ID`, `user_ID`, `product_ID`, `qty`) VALUES
(1, 1, 5, 1),
(2, 1, 6, 2),
(9, 17, 10, 1),
(10, 17, 20, 2),
(11, 17, 79, 2);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_ID` int(20) NOT NULL,
  `category_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_ID`, `category_name`) VALUES
(1, 'Electronics'),
(2, 'Furnitures'),
(3, 'Clothe'),
(4, 'Shoes'),
(5, 'Tools'),
(8, 'Food'),
(9, 'Office supplies');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `user_ID` int(20) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`user_ID`, `customer_name`, `address`, `contact`) VALUES
(2, 'Best Buy', '123 72nd Ave, Surrey', '604-273-5716'),
(10, 'CanadianTire', '123 Street', '123 234 123'),
(15, 'Walmart', '67890 Lougheed', '7781231234'),
(17, 'Cosco Corp', '567 70 St, Rich', '(778)123456098'),
(18, 'Mark Company', '123 St, Van, bC', '604-123-1234'),
(21, 'superstore', '321 Ave st', '123-123-1230');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_ID` int(20) NOT NULL,
  `user_ID` int(20) NOT NULL,
  `action` varchar(100) NOT NULL,
  `product_ID` int(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `inventory_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_ID`, `user_ID`, `action`, `product_ID`, `quantity`, `inventory_date`) VALUES
(41, 2, 'Purchase', 24, 1, '2018-12-09 15:52:49'),
(42, 2, 'Purchase', 31, 1, '2018-12-09 15:56:29'),
(43, 2, 'Purchase', 10, 2, '2018-12-09 16:24:34'),
(44, 2, 'Purchase', 23, 1, '2018-12-09 16:25:33'),
(45, 2, 'Purchase', 25, 1, '2018-12-09 16:27:25'),
(46, 2, 'Purchase', 30, 1, '2018-12-09 16:29:51'),
(47, 10, 'Purchase', 31, 0, '2018-12-09 17:50:46'),
(48, 10, 'Purchase', 32, 2, '2018-12-09 17:51:35'),
(49, 2, 'Purchase', 20, 2, '2018-12-12 08:04:33'),
(50, 2, 'Purchase', 10, 1, '2018-12-12 08:07:34'),
(51, 2, 'Purchase', 30, 2, '2018-12-12 10:58:02'),
(52, 17, 'Purchase', 20, 1, '2018-12-12 11:02:00'),
(53, 17, 'Purchase', 24, 2, '2018-12-12 11:02:00'),
(54, 17, 'Purchase', 10, 1, '2018-12-12 11:02:01'),
(55, 17, 'Purchase', 23, 1, '2018-12-12 11:53:49'),
(56, 12, 'Add Product', 34, 50, '2018-12-13 14:51:33'),
(57, 13, 'Add Product', 35, 100, '2018-12-13 16:08:52'),
(58, 1, 'Add Product', 36, 100, '2018-12-13 19:36:59'),
(59, 1, 'Add Product', 37, 200, '2018-12-14 16:02:00'),
(60, 1, 'Add Product', 38, 12, '2018-12-15 17:23:02'),
(61, 12, 'Add Product', 39, 12, '2018-12-15 17:37:43'),
(62, 13, 'Add Product', 38, 20, '2018-12-16 09:53:20'),
(63, 13, 'Add Product', 39, 30, '2018-12-16 17:41:41'),
(64, 12, 'Add Product', 40, 12, '2018-12-16 20:06:58'),
(65, 1, 'Add Product', 41, 21, '2018-12-16 20:10:16'),
(66, 12, 'Update Quantity', 40, 30, '2018-12-17 07:10:48'),
(67, 12, 'Update Quantity', 40, 35, '2018-12-17 11:32:11'),
(68, 12, 'Add Product', 42, 90, '2018-12-17 11:38:05'),
(69, 12, 'Update Quantity', 42, 190, '2018-12-17 12:44:04'),
(70, 12, 'Update Quantity', 42, 195, '2018-12-17 14:45:06'),
(71, 12, 'Update Quantity', 40, 55, '2018-12-17 14:55:42'),
(72, 12, 'Add Product', 43, 1, '2018-12-17 15:50:24'),
(73, 12, 'Add Product', 44, 2, '2018-12-17 15:50:58'),
(74, 12, 'Add Product', 45, 12, '2018-12-17 16:46:36'),
(75, 1, 'Add Product', 46, 2, '2018-12-17 16:56:13'),
(76, 1, 'Add Product', 47, 7, '2018-12-17 17:03:38'),
(77, 2, 'Purchase', 25, 3, '2018-12-17 17:07:19'),
(78, 16, 'Purchase', 24, 2, '2018-12-18 06:18:38'),
(79, 16, 'Purchase', 28, 2, '2018-12-18 06:38:39'),
(80, 16, 'Purchase', 25, 1, '2018-12-20 06:48:46'),
(81, 16, 'Purchase', 26, 2, '2018-12-20 06:54:19'),
(82, 16, 'Purchase', 23, 5, '2018-12-20 12:13:38'),
(83, 16, 'Purchase', 10, 2, '2018-12-21 15:45:38'),
(84, 16, 'Purchase', 20, 1, '2018-12-21 15:45:38'),
(85, 16, 'Purchase', 27, 1, '2018-12-21 15:55:31'),
(86, 16, 'Purchase', 32, 1, '2018-12-21 16:03:10'),
(87, 16, 'Purchase', 34, 2, '2018-12-21 16:06:19'),
(88, 2, 'Purchase', 23, 1, '2018-12-25 19:19:41'),
(89, 2, 'Purchase', 37, 2, '2018-12-25 19:34:12'),
(90, 1, 'Update Quantity', 28, 80, '2018-12-25 19:47:01'),
(91, 2, 'Purchase', 20, 3, '2018-12-26 11:44:37'),
(92, 2, 'Purchase', 10, 2, '2018-12-26 14:43:28'),
(93, 10, 'Purchase', 28, 1, '2018-12-26 15:35:11'),
(94, 10, 'Purchase', 27, 1, '2018-12-26 16:02:41'),
(95, 13, 'Add Product', 48, 3, '2018-12-26 16:31:30'),
(96, 2, 'Purchase', 35, 2, '2018-12-27 10:31:41'),
(97, 13, 'Update Quantity', 38, 29, '2018-12-27 11:46:53'),
(98, 13, 'Update Quantity', 38, 300, '2018-12-27 11:47:55'),
(99, 1, 'Add Product', 48, 5, '2018-12-27 14:12:21'),
(100, 1, 'Update Quantity', 48, 55, '2018-12-27 14:20:02'),
(101, 1, 'Update Quantity', 48, 550, '2018-12-27 14:21:33'),
(102, 1, 'Update Quantity', 48, 0, '2018-12-27 14:37:16'),
(103, 1, 'Update Quantity', 48, 12, '2018-12-27 14:38:15'),
(104, 1, 'Add Product', 49, 10, '2018-12-27 14:57:12'),
(105, 1, 'Add Product', 50, 12, '2018-12-27 14:58:50'),
(106, 15, 'Purchase', 20, 1, '2018-12-27 15:27:57'),
(107, 15, 'Purchase', 25, 2, '2018-12-27 15:27:57'),
(108, 1, 'Update Quantity', 39, 30, '2018-12-27 20:00:21'),
(109, 1, 'Update Quantity', 50, 122, '2018-12-28 08:18:29'),
(110, 1, 'Add Product', 50, 90, '2018-12-29 15:19:22'),
(111, 12, 'Add Product', 51, 3, '2018-12-29 15:25:11'),
(112, 12, 'Add Product', 52, 3, '2018-12-29 15:30:52'),
(113, 12, 'Add Product', 53, 3, '2018-12-29 15:34:37'),
(114, 1, 'Add Product', 54, 32, '2018-12-29 19:46:43'),
(115, 1, 'Update Quantity', 54, 32, '2018-12-29 19:47:30'),
(116, 1, 'Update Quantity', 54, 32, '2018-12-29 19:49:38'),
(117, 1, 'Update Quantity', 54, 32, '2018-12-29 19:50:00'),
(118, 1, 'Update Quantity', 54, 32, '2018-12-29 19:50:32'),
(119, 1, 'Update Quantity', 54, 32, '2018-12-29 19:51:13'),
(120, 1, 'Update Quantity', 54, 35, '2018-12-29 19:57:13'),
(121, 12, 'Add Product', 55, 12, '2018-12-30 20:16:53'),
(122, 12, 'Add Product', 56, 12, '2018-12-31 08:25:37'),
(123, 12, 'Add Product', 56, 87, '2018-12-31 15:47:12'),
(124, 12, 'Update Quantity', 56, 89, '2018-12-31 15:47:27'),
(125, 13, 'Update Quantity', 38, 3300, '2019-01-01 10:56:20'),
(126, 13, 'Add Product', 56, 50, '2019-01-01 11:29:35'),
(127, 13, 'Add Product', 57, 67, '2019-01-01 11:36:33'),
(128, 1, 'Update Quantity', 0, 982, '2019-01-01 11:57:02'),
(129, 1, 'Update Quantity', 0, 982, '2019-01-01 11:57:24'),
(130, 1, 'Update Quantity', 20, 982, '2019-01-01 11:58:32'),
(131, 1, 'Update Quantity', 20, 982, '2019-01-01 12:03:25'),
(132, 1, 'Update Quantity', 20, 982, '2019-01-01 12:05:42'),
(133, 1, 'Update Quantity', 20, 3300, '2019-01-01 12:22:41'),
(134, 1, 'Update Quantity', 50, 900, '2019-01-01 14:27:23'),
(135, 1, 'Update Quantity', 0, 800, '2019-01-01 14:28:31'),
(136, 1, 'Update Quantity', 23, 800, '2019-01-01 14:30:54'),
(137, 1, 'Add Product', 58, 90, '2019-01-01 15:48:53'),
(138, 17, 'Purchase', 24, 1, '2019-01-01 16:18:13'),
(139, 17, 'Purchase', 28, 2, '2019-01-01 16:22:23'),
(140, 17, 'Purchase', 27, 3, '2019-01-01 16:22:51'),
(141, 12, 'Add Product', 59, 100, '2019-01-01 19:55:41'),
(142, 13, 'Add Product', 60, 10, '2019-01-02 10:11:44'),
(143, 13, 'Update Quantity', 35, 198, '2019-01-02 10:23:43'),
(144, 13, 'Update Quantity', 35, 198, '2019-01-02 10:24:10'),
(145, 13, 'Update Quantity', 30, 940, '2019-01-02 10:43:58'),
(146, 13, 'Update Quantity', 56, 500, '2019-01-02 10:49:51'),
(147, 13, 'Add Product', 61, 12, '2019-01-02 10:50:52'),
(148, 1, 'Edit Product', 59, 100, '2019-01-02 11:03:54'),
(149, 12, 'Edit Product', 44, 200, '2019-01-02 11:08:01'),
(150, 12, 'Add Product', 62, 56, '2019-01-02 11:10:24'),
(151, 12, 'Edit Product', 34, 488, '2019-01-02 14:12:01'),
(152, 12, 'Add Product', 63, 20, '2019-01-02 14:12:26'),
(153, 12, 'Add Product', 64, 12, '2019-01-02 14:16:28'),
(154, 1, 'Edit Product', 63, 20, '2019-01-02 14:43:55'),
(155, 1, 'Edit Product', 63, 20, '2019-01-02 14:44:07'),
(156, 1, 'Edit Product', 30, 940, '2019-01-02 14:52:11'),
(157, 12, 'Add Product', 64, 12, '2019-01-04 19:42:10'),
(158, 12, 'Add Product', 65, 80, '2019-01-04 20:29:31'),
(159, 12, 'Edit Product', 65, 81, '2019-01-04 20:40:17'),
(160, 12, 'Edit Product', 65, 82, '2019-01-05 07:44:29'),
(161, 12, 'Edit Product', 66, 5, '2019-01-05 08:08:29'),
(162, 12, 'Edit Product', 66, 5, '2019-01-05 08:08:51'),
(163, 1, 'Edit Product', 63, 320, '2019-01-05 10:33:25'),
(164, 17, 'Purchase', 29, 2, '2019-01-06 07:35:56'),
(165, 17, 'Purchase', 53, 1, '2019-01-06 07:44:58'),
(166, 17, 'Purchase', 53, 3, '2019-01-06 07:47:50'),
(167, 17, 'Purchase', 31, 1, '2019-01-06 07:58:10'),
(168, 17, 'Purchase', 27, 3, '2019-01-06 08:07:20'),
(169, 17, 'Purchase', 23, 1, '2019-01-06 08:23:32'),
(170, 17, 'Purchase', 25, 1, '2019-01-06 10:38:49'),
(171, 12, 'Edit Product', 67, 30, '2019-01-07 14:04:14'),
(172, 12, '12', 0, 74, '2019-01-07 15:51:52'),
(173, 12, '12', 0, 75, '2019-01-07 15:52:22'),
(174, 12, 'Add Product', 76, 76, '2019-01-07 15:57:34'),
(175, 12, 'Add Product', 77, 2, '2019-01-07 16:05:32'),
(176, 12, 'Edit Product', 77, 20, '2019-01-07 16:14:16'),
(177, 1, 'Edit Product', 78, 0, '2019-01-07 17:10:25'),
(178, 1, 'Edit Product', 78, 1, '2019-01-07 17:11:01'),
(179, 1, 'Edit Product', 78, 10, '2019-01-07 20:05:38'),
(180, 17, 'Purchase', 32, 2, '2019-01-08 07:27:48'),
(181, 17, 'Purchase', 24, 2, '2019-01-08 07:38:43'),
(182, 17, 'Purchase', 24, 1, '2019-01-08 07:42:51'),
(183, 1, 'Edit Product', 79, 0, '2019-01-19 08:14:06'),
(184, 1, 'Edit Product', 79, 5, '2019-01-19 08:15:31'),
(185, 1, 'Edit Product', 79, 0, '2019-01-19 08:15:52'),
(186, 1, 'Edit Product', 79, 5, '2019-01-19 08:16:56'),
(187, 1, 'Edit Product', 23, 799, '2019-01-23 15:01:37');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_ID` int(20) NOT NULL,
  `category_ID` int(20) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_price` double NOT NULL,
  `product_qty` int(20) NOT NULL,
  `picture` varchar(200) NOT NULL,
  `supplier_ID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_ID`, `category_ID`, `product_name`, `product_price`, `product_qty`, `picture`, `supplier_ID`) VALUES
(10, 1, 'Sony PC - 500GB', 600, 991, 'picture/24_1529879553.jpg', 4),
(20, 1, 'Ipad 12 inch 30 GB', 200, 3300, 'picture/20.jpg', 4),
(23, 1, 'PC 15\\\' 500GB ', 350, 799, 'picture/pc_1548284497.jpg', 4),
(24, 4, 'Leather Shoe', 100, 13, 'picture/25_1529791332.jpg', 11),
(25, 4, 'Merrel Running Shoe', 90, 0, 'picture/Merrell Mix master 2_1529791978.jpg', 11),
(26, 2, 'Table Set', 200, 95, 'picture/tableSet_1529793500.jpg', 14),
(27, 2, 'sofa ', 500, 22, 'picture/sofa_1529793622.jpg', 14),
(28, 2, 'Bed', 1000, 77, 'picture/bed_1529793972.jpg', 14),
(29, 5, 'Tools set', 30, 98, 'picture/toolSet_1529794178.jpg', 13),
(30, 5, 'hammer', 100, 940, 'picture/noImage_1546141873_1546469531.jpg', 13),
(31, 3, 'Pants', 20, 98, 'picture/pants_1529795637.jpg', 12),
(32, 3, 'shirt', 10, 195, 'picture/shirt_1529795825.jpg', 12),
(33, 3, 'coat', 25, 50, 'picture/coat_1529879043.jpg', 12),
(34, 3, 'Hat wool', 155, 488, 'picture/hat_1544741492.jpg', 12),
(35, 5, 'drills', 200, 198, 'picture/drill_1546453450.jpg', 13),
(36, 3, 'Jeans', 30, 100, 'picture/jeans_1544758619.jpg', 12),
(37, 4, 'Nike shoe', 150, 198, 'picture/nike_1544832120.jpg', 11),
(39, 5, 'Ladder', 200, 30, 'picture/25_1546370705.jpg', 13),
(41, 2, 'sit2', 12, 21, '', 14),
(45, 1, 'smart Pad', 12, 12, 'picture/20_1545144214.jpg', 12),
(47, 0, 'warm', 90, 7, '', 14),
(49, 4, 'nice', 10, 10, '', 11),
(50, 1, 'saw2', 90, 900, 'picture/saw_1546374317.png', 4),
(53, 3, 'cool', 2, -1, 'picture/noImage_1546381892.jpg', 12),
(56, 5, 'saw', 200, 500, 'picture/saw_1546370975.png', 13),
(58, 5, 'po', 9, 90, 'picture/hammer_1546386533.jpg', 20),
(59, 2, 'sleep bed', 10, 100, '', 12),
(62, 3, 'Comfy fur', 56, 56, '', 12),
(66, 3, 'van', 5, 5, 'picture/20_1546704531.jpg', 12),
(67, 2, 'sunny', 30, 30, 'picture/drill_1546898654.jpg', 12),
(68, 4, 'jan5', 80, 80, 'picture/25_1546717085.jpg', 11),
(71, 1, 'su', 2, 2, 'picture/24_1546899511.jpg', 12),
(77, 3, 'rt3', 20, 20, 'picture/20_1546906456.jpg', 12),
(79, 8, 'sushi', 12, 5, 'picture/sushi_1547914446.jpg', 28);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_ID` int(20) NOT NULL,
  `user_ID` int(20) NOT NULL,
  `sales_total` double NOT NULL,
  `sales_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_ID`, `user_ID`, `sales_total`, `sales_date`) VALUES
(31, 2, 20, '2018-12-09 15:56:29'),
(32, 2, 1199.98, '2018-12-09 16:24:33'),
(33, 2, 0, '2018-12-09 16:24:44'),
(34, 2, 300, '2018-12-09 16:25:33'),
(35, 2, 90, '2018-12-09 16:27:25'),
(36, 2, 10, '2018-12-09 16:29:51'),
(37, 10, 0, '2018-12-09 17:49:32'),
(38, 10, 0, '2018-12-09 17:50:45'),
(39, 10, 20, '2018-12-09 17:51:34'),
(40, 10, 0, '2018-12-09 17:51:50'),
(41, 2, 598, '2018-12-12 08:04:33'),
(42, 2, 599.99, '2018-12-12 08:07:34'),
(43, 2, 20, '2018-12-12 10:58:02'),
(44, 17, 1098.99, '2018-12-12 11:02:00'),
(45, 17, 300, '2018-12-12 11:53:49'),
(46, 2, 270, '2018-12-17 17:07:19'),
(56, 2, 300, '2018-12-25 19:19:41'),
(57, 2, 300, '2018-12-25 19:34:12'),
(58, 2, 897, '2018-12-26 11:44:36'),
(59, 2, 1199.98, '2018-12-26 14:43:28'),
(60, 10, 1000, '2018-12-26 15:35:11'),
(61, 10, 500, '2018-12-26 16:02:41'),
(62, 2, 40, '2018-12-27 10:31:41'),
(63, 15, 479, '2018-12-27 15:27:57'),
(64, 17, 100, '2019-01-01 16:18:12'),
(65, 17, 2000, '2019-01-01 16:22:23'),
(66, 17, 1500, '2019-01-01 16:22:51'),
(67, 17, 60, '2019-01-06 07:35:56'),
(68, 17, 2, '2019-01-06 07:44:57'),
(69, 17, 6, '2019-01-06 07:47:50'),
(70, 17, 20, '2019-01-06 07:58:09'),
(71, 17, 1500, '2019-01-06 08:07:19'),
(72, 17, 350, '2019-01-06 08:23:32'),
(73, 17, 2000, '2019-01-06 10:26:37'),
(74, 17, 200, '2019-01-06 10:35:26'),
(75, 17, 90, '2019-01-06 10:38:49'),
(76, 17, 20, '2019-01-08 07:27:48'),
(77, 17, 100, '2019-01-08 07:32:54'),
(78, 17, 200, '2019-01-08 07:38:43'),
(79, 17, 100, '2019-01-08 07:42:50');

-- --------------------------------------------------------

--
-- Table structure for table `sales_detail`
--

CREATE TABLE `sales_detail` (
  `sales_detail_ID` int(20) NOT NULL,
  `sales_ID` int(20) NOT NULL,
  `product_ID` int(20) NOT NULL,
  `sales_qty` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_detail`
--

INSERT INTO `sales_detail` (`sales_detail_ID`, `sales_ID`, `product_ID`, `sales_qty`) VALUES
(20, 12, 5, 1),
(21, 13, 22, 2),
(22, 13, 21, 3),
(23, 14, 6, 1),
(24, 16, 23, 1),
(25, 17, 1, 1),
(26, 19, 2, 1),
(27, 20, 3, 1),
(28, 21, 23, 1),
(29, 22, 23, 1),
(30, 23, 25, 1),
(31, 24, 25, 1),
(32, 26, 26, 2),
(33, 27, 30, 3),
(34, 28, 6, 2),
(35, 29, 10, 1),
(36, 30, 26, 1),
(37, 30, 24, 1),
(38, 31, 31, 1),
(39, 32, 10, 2),
(40, 34, 23, 1),
(41, 35, 25, 1),
(42, 36, 30, 1),
(43, 38, 31, 0),
(44, 39, 32, 2),
(45, 41, 20, 2),
(46, 42, 10, 1),
(47, 43, 30, 2),
(48, 44, 20, 1),
(49, 44, 24, 2),
(50, 44, 10, 1),
(51, 45, 23, 1),
(52, 46, 25, 3),
(53, 47, 24, 2),
(54, 48, 28, 2),
(55, 49, 25, 1),
(56, 50, 26, 2),
(57, 51, 23, 5),
(58, 52, 10, 2),
(59, 52, 20, 1),
(60, 53, 27, 1),
(61, 54, 32, 1),
(62, 55, 34, 2),
(63, 56, 23, 1),
(64, 57, 37, 2),
(65, 58, 20, 3),
(66, 59, 10, 2),
(67, 60, 28, 1),
(68, 61, 27, 1),
(69, 62, 35, 2),
(70, 63, 20, 1),
(71, 63, 25, 2),
(72, 64, 24, 1),
(73, 65, 28, 2),
(74, 66, 27, 3),
(75, 67, 29, 2),
(76, 68, 53, 1),
(77, 69, 53, 3),
(78, 70, 31, 1),
(79, 71, 27, 3),
(80, 72, 23, 1),
(81, 75, 25, 1),
(82, 76, 32, 2),
(83, 78, 24, 2),
(84, 79, 24, 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `user_ID` int(20) NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`user_ID`, `supplier_name`, `address`, `contact`) VALUES
(4, 'Profitable Electronics Corporation', '900 St, Vancouver, BC', '7780001234'),
(11, 'Happy Shoe Ltd', '234 St, Surrey, BC', '6041230987'),
(12, 'Comfortable Clothe ', '543 Pender St', '604-0123'),
(13, 'Max Super Tools Ltd', '123 abc Ave, Burnaby, BC', '7783410988'),
(14, 'Elegant Furniture Corp', '678 Kinggeorge St, surrey, BC', '6047538723'),
(19, 'Winners', '123 104 Ave', '778-129-0909'),
(20, 'Tody Comp', '123 st', '778'),
(28, 'Fast delivery', '123 speedy Ave', '500-123-098');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_ID` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `access` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_ID`, `username`, `password`, `access`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1),
(2, 'BestBuy', '71f3cd2250db71dc008b0bb79cd22f38587f85e6', 3),
(4, 'sam', 'f16bed56189e249fe4ca8ed10a1ecae60e8ceac0', 2),
(10, 'CanadianTire', '907f936847b49587cbc775d36ec4f68bb0e4edd5', 3),
(11, 'mary', '5665331b9b819ac358165f8c38970dc8c7ddb47d', 2),
(12, 'jack', '596727c8a0ea4db3ba2ceceedccbacd3d7b371b8', 2),
(13, 'john', 'a51dda7c7ff50b61eaea0444371f4a6a9301e501', 2),
(14, 'tom', '96835dd8bfa718bd6447ccc87af89ae1675daeca', 2),
(15, 'Walmart', '6474065d0a8e43d902aebe62d8dc7e0f86be53fd', 3),
(17, 'cosco', 'b47a91ea74102d0175daa7f3eda78bd67ceaf36a', 3),
(18, 'mark', '85f22af39ee4b22bfa8474bc4a8d606399e3899d', 3),
(19, 'win', 'd9734636b6c39d6823127a74e005810bf651d6c2', 2),
(20, 'tode', '15e3897d9076e53842dcfd7a8c11a2a3046f1834', 2),
(21, 'superstore', '1f1c47f5bf305994d1a02bbabc88289994cc6ccd', 3),
(28, 'fast', '0afde56699db99c43c6254d81ccc16fbb7096ad3', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`user_ID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_ID`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_ID`);

--
-- Indexes for table `sales_detail`
--
ALTER TABLE `sales_detail`
  ADD PRIMARY KEY (`sales_detail_ID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`user_ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT for table `sales_detail`
--
ALTER TABLE `sales_detail`
  MODIFY `sales_detail_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
