<?php
	include('conn.php');
	session_start();
	
$username=$_POST['username'];
$password=$_POST['password'];

//prevent MySQL injection attack
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysqli_real_escape_string($conn,$_POST["username"]);
$password = mysqli_real_escape_string($conn,$_POST["password"]);

		

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$username=$_POST['username'];
		
		if (!preg_match("/^[a-zA-Z0-9_]*$/",$username)) {
			$_SESSION['msg'] = "Username can't have space and special character!"; 
			header('location: index.php');
		}
		else{
			
		$usr=$username;
		
		$password =$_POST["password"];
		$pswd=SHA1($password);
		
		$query=mysqli_query($conn,"SELECT * FROM user 
									WHERE username='$usr' 
									AND password='$pswd'");
		
		if(mysqli_num_rows($query)==0){
			$_SESSION['msg'] = "Wrong User Name or Password!";
			header('location: index.php');
		}
		else{
			
			$row=mysqli_fetch_array($query);
			if ($row['access']==1){
				$_SESSION['id']=$row['user_ID'];
				?>
				<script>
					window.alert('Welcome, Admin!');
					window.location.href='admin/';
				</script>
				<?php
			}
			elseif ($row['access']==2){
				$_SESSION['id']=$row['user_ID'];
				?>
				<script>
					window.alert('Welcome, Supplier!');
					window.location.href='supplier/';
				</script>
				<?php
			}
			else{
				$_SESSION['id']=$row['user_ID'];
				?>
				<script>
					window.alert('Welcome, Customer!');
					window.location.href='customer/';
				</script>
				<?php
			}
		}
		
		}
	}
?>