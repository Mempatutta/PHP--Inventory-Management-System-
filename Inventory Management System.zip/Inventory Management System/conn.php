<?php

$conn = mysqli_connect("localhost","root","","warehouse")or die();


 
?>