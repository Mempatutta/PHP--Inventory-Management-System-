<?php

	include('session.php');
	if(isset($_POST['num'])){
		$search = mysqli_real_escape_string($conn,$_POST['name']);
		$query=mysqli_query($conn,"SELECT * FROM `product` 
									WHERE product_name LIKE '%$search%'");
		echo mysqli_num_rows($query);
	}
?>