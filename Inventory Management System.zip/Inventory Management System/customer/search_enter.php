<?php include('session.php'); ?>
<?php include('header.php'); ?>
<?php 
	$name=mysqli_real_escape_string($conn,$_POST['search']); 
?>
<body>
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
<script src="methods.js"></script>
<div class="container">
	<?php include('myCart_popUp.php'); ?>
	<div style="height: 120px;"></div>
	<div>
	<?php
		$prdct_clmn=4;
		$query=mysqli_query($conn,"SELECT * FROM product 
									WHERE product_name 
									LIKE '%$name%'");
		while($row=mysqli_fetch_array($query)){
			
			$prdct_clmn = ($prdct_clmn == 4) ? 1 : $prdct_clmn+1; 
			if($prdct_clmn == 1) 
				echo "<div class='row'>";  
			
			?>
				<div class="col-lg-3">
				<div>
					<img src="../<?php 
					($row['picture'])?print $row['picture']:print "picture/noImage2.jpg"; ?>" 
					style="width: 300px; height:300px; padding:auto; margin:auto;" class="thumbnail">
					<div style="height: 20px;"></div>
					<div style="height:120px; width:230px; margin-left:17px;"><?php echo $row['product_name']; ?></div>
					<div style="height: 20px;"></div>
					<div style="display:none; position:absolute; top:210px; left:10px;" class="well" id="cart<?php echo $row['product_ID']; ?>">Qty: 
					<input type="text" style="width:40px;" id="qty<?php echo $row['product_ID']; ?>"> 
					<button type="button" class="btn btn-primary btn-sm concart" value="<?php echo $row['product_ID']; ?>">
					<i class="fa fa-shopping-cart fa-fw"></i></button></div>
					<div style="margin-left:17px; margin-right:17px;">
						<button type="button" class="btn btn-primary btn-sm addcart" value="<?php echo $row['product_ID']; ?>"><i class="fa fa-shopping-cart fa-fw"></i> Add to Cart</button> <span class="pull-right"><strong><?php echo number_format($row['product_price'],2); ?></strong></span> 
					</div>
				</div>
				</div>
			<?php
		if($prdct_clmn == 4) echo "</div><div style='height: 100px;'></div>";
		}
		if($prdct_clmn == 1) echo "<div class='col-lg-3></div><div class='col-lg-3'></div><div class='col-lg-3'></div></div>"; 
		if($prdct_clmn == 2) echo "<div class='col-lg-3'></div><div class='col-lg-3'></div></div>"; 
		if($prdct_clmn == 3) echo "<div class='col-lg-3'></div></div>"; 
	?>
	</div>
</div>

</body>
</html>