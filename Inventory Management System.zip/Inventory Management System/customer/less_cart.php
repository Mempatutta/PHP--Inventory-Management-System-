<?php

	include('session.php');
	if(isset($_POST['less'])){
		$id=mysqli_real_escape_string($conn,$_POST['id']);
		
		$query=mysqli_query($conn,"SELECT * FROM cart 
									WHERE product_ID='$id'");
		$row=mysqli_fetch_array($query);
		
		$newqty=$row['qty']-1;
		
		if ($newqty==0){
			
			delete_cart($conn,$id);
		}
		else{
			
			
		update_cart($conn,  $newqty, $id);}

		}
	
	function delete_cart($conn,$id) {
		  
		$stmt = $conn->prepare("DELETE FROM cart WHERE product_ID=?");
			$stmt->bind_param('i',$id);
			$stmt->execute();
			$stmt->close();
		return $stmt;
	}
	
	function update_cart($conn,$newqty, $id) {
		  
		$stmt = $conn->prepare("UPDATE cart 
								SET  qty=? 
								WHERE product_ID=?");
		$stmt->bind_param('ii', $newqty, $id);
		$stmt->execute();
		$stmt->close();
		
		return $stmt;
	}
	

?>