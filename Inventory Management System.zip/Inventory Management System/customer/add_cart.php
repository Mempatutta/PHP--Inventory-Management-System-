<?php

	include('session.php');
	if(isset($_POST['cart'])){
		$id=mysqli_real_escape_string($conn,$_POST['id']);
		$qty=mysqli_real_escape_string($conn,$_POST['qty']);
		
		$query=mysqli_query($conn,"SELECT * FROM cart 
							WHERE product_ID='$id' 
							AND user_ID='".$_SESSION['id']."'");
		if (mysqli_num_rows($query)>0){
			echo "Product is on cart!";
		}
		else{
			add_cart($conn, $id, $qty);
		}
	}	
		
		function add_cart($conn, $id, $qty){
		  
		$stmt = $conn->prepare("INSERT INTO cart 
								(user_ID, product_ID, qty) 
								VALUES (?,?,?)");
			$stmt->bind_param('iii',$_SESSION['id'], $id, $qty);
			$stmt->execute();
			$stmt->close();
		return $stmt;
	}
		
	

?>