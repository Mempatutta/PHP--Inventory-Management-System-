<?php
	include('session.php');
	if(isset($_POST['discard'])){
		$id=mysqli_real_escape_string($conn,$_POST['id']);
		
		
		delete_cart($conn,$id);}
	
		function delete_cart($conn,$id) {
		  
			$stmt = $conn->prepare("DELETE FROM cart 
								WHERE product_ID=? 
								AND user_ID=?");
			$stmt->bind_param('ii',$id,$_SESSION['id']);
			$stmt->execute();
			$stmt->close();
		return $stmt;
	
	}
?>