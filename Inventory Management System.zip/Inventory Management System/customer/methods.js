function showCart(){
	$.ajax({
		url:"get_cart.php",
		method:"POST",
		data:{
			scart: 1,
		},
		success:function(response){
			$('#cart_area').html(response);
			$('#cart_box').show();
			$('#cartme').addClass('active');
			$("#cart_area").scrollTop($("#cart_area")[0].scrollHeight);
		}
	});
}
function closeCart(){
	$('#cart_box').hide();
	$('#cartme').deleteClass('active');
}

function showCheckout(){
	$.ajax({
		url:"get_checkout.php",
		method:"POST",
		data:{
			check: 1,
		},
		success:function(response){
			$('#checkout_area').html(response);
		}
	});
}
$(document).ready(function(){
	
	$(document).on('click', '.addcart', function(){
		var product_id=$(this).val();
		if ($('#cart'+product_id).is(':visible')){
			$('#cart'+product_id).hide();	
		}
		else{
			$('#cart'+product_id).show();
		}
	});
	
	$(document).on('click', '.concart', function(){
		var product_id=$(this).val();
		var qty=$('#qty'+product_id).val();
		$('#cart'+product_id).hide();
		if (qty.match(/^\d+$/)){
			
			$.ajax({
				url:"add_cart.php",
				method:"POST",
				data:{
					id: product_id,
					qty: qty,
					cart: 1,
				},
				success:function(data){
					if(data!=""){
						alert(data);
					}
					else{
						showCart();
					}
				}
			});
			
		}
		else if (qty==""){
			alert('Please input value');
		}
		else{
			alert('Please input number');
		}
	});
	
	$(document).on('click', '.discard_product', function(){
		var product_id=$(this).val();
			$.ajax({
				url:"delete_cart.php",
				method:"POST",
				data:{
					id: product_id,
					discard: 1,
				},
				success:function(){
					showCart();
				}
			});
	});
	
	$(document).on('click', '#close_cart', function(){
		closeCart();
	});
	
	$(document).on('click', '#cart_control', function(){
		if($('#cart_area').is(':visible')){
			closeCart();
		}
		else{
			showCart();
		}
	});
	
	$(document).on('click', '#check', function(){
		var total=$('#total').text();
		window.location.href='make_payment.php?total='+total;
	});
	
	$(document).on('click', '.discard_prod', function(){
		var prodid=$(this).val();
		$.ajax({
			url:"delete_cart.php",
			method:"POST",
			data:{
				id: prodid,
				discard: 1,
			},
			success:function(data){
				showCheckout();
			}
		});
	});
	
	$(document).on('click', '.less_qty', function(){
		var prodid=$(this).val();
		$.ajax({
			url:"less_cart.php",
			method:"POST",
			data:{
				id: prodid,
				less: 1,
			},
			success:function(){
				showCart();
			}
		});
	});
	
	$(document).on('click', '.less_qty2', function(){
		var prodid=$(this).val();
		$.ajax({
			url:"less_cart.php",
			method:"POST",
			data:{
				id: prodid,
				less: 1,
			},
			success:function(){
				showCheckout();
			}
		});
	});
	
	$(document).on('click', '.plus_qty', function(){
		var prodid=$(this).val();
		$.ajax({
			url:"plus_cart.php",
			method:"POST",
			data:{
				id: prodid,
				plus: 1,
			},
			success:function(){
				showCart();
			}
		});
	});
	
	$(document).on('click', '.plus_qty2', function(){
		var prodid=$(this).val();
		$.ajax({
			url:"plus_cart.php",
			method:"POST",
			data:{
				id: prodid,
				plus: 1,
			},
			success:function(){
				showCheckout();
			}
		});
	});
	
	$("#search").keyup(function() {
		var name = $('#search').val();
		if (name == "") {
			$("#search_area").hide();
		}
		else {
			$.ajax({
			type: "POST",
			url: "search_modal.php",
			data: {
				name: name,
				num: 1
			},
			success: function(num) {
				showSearch(num, name);
			}
			});
		}
	});
	
});



function showSearch(num, name){
	var height;
	if (num==0){
		height=50;
	}
	else if(num>=5){
		height=330;
	} 
	else{
		height=50*num;
	}
	$.ajax({
		url:"search.php",
		method:"POST",
		data:{
			name: name,
			ss: 1,
		},
		success:function(response){
			$('#search_area').html(response).show();
			$('#search_area').height(height);
		}
	});
}


