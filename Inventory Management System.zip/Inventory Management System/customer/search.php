<?php
	include('session.php');
	if(isset($_POST['ss'])){
	$search = mysqli_real_escape_string($conn,$_POST['name']);
	$query=mysqli_query($conn,"SELECT * FROM `product` 
						WHERE product_name LIKE '%$search%' LIMIT 8");
	
	
	if(mysqli_num_rows($query)==0){
		
		?>
		<div style="position:relative; left:30px; top:15px;">No matching product found!</div>
		<?php
		
	}
	else{
		
		while ($row = mysqli_fetch_array($query)) {
		?>
 
			<div style="position:relative; left:30px; top:10px;">
				<a href="search_suggest.php?id=<?php echo $row['product_ID']; ?>">
				<?php echo $row['product_name']; ?></a><br><br>
			</div>
	
		<?php
		}
		
	}
	}
?>