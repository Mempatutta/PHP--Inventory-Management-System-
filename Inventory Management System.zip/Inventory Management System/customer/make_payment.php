<?php
	include('session.php');
	header('location: history.php');
	$total=mysqli_real_escape_string($conn,$_GET['total']);

	//takes out commas from total $
	preg_match("/^[0-9,]+$/", $total)?$new=$total:$new = str_replace(',', '', $total);

	update_sales($conn,  $new);
	function update_sales($conn,$new) {
		  
		$stmt = $conn->prepare("INSERT INTO sales 
	(user_ID, sales_total, sales_date)  
	VALUES (?,?,NOW())");
	
	$stmt->bind_param('id',$_SESSION['id'], $new);

	$stmt->execute();
	$stmt->close();
		return $stmt;
	}
	$sale_id=mysqli_insert_id($conn);
	
	$query=mysqli_query($conn,"SELECT * FROM cart 
								WHERE user_ID='".$_SESSION['id']."'");
								
	
	while($row=mysqli_fetch_array($query)){
		
	$stmt = $conn->prepare("INSERT INTO sales_detail 
						(sales_ID, product_ID, sales_qty)
						VALUES (?,?,?)");
	$stmt->bind_param('iii',$sale_id, $row['product_ID'], $row['qty']);
	$stmt->execute();
	$stmt->close();
	
	
	
		$prdct_id=mysqli_query($conn,"SELECT * FROM product 
		WHERE product_ID='".$row['product_ID']."'");
		
		
		$prdct_row=mysqli_fetch_array($prdct_id);
		
		$newqty=$prdct_row['product_qty']-$row['qty'];
		
		
		$stmt = $conn->prepare("UPDATE product 
								SET  product_qty=? 
								WHERE product_ID=?");
    $stmt->bind_param('ii', $newqty, $row['product_ID']);
    $stmt->execute();
	$stmt->close();
		
		
	$a="Purchase";
	$stmt = $conn->prepare("INSERT INTO inventory 
		(user_ID, action, product_ID, quantity, inventory_date)
						VALUES (?,?,?,?,NOW())");
	$stmt->bind_param('isii',$_SESSION['id'], $a,$row['product_ID'],$row['qty']);
	$stmt->execute();
	$stmt->close();
	}

	delete_cart($conn);
	function delete_cart($conn) {
		  
		$stmt = $conn->prepare("DELETE FROM cart WHERE user_ID=?");
	$stmt->bind_param('i',$_SESSION['id']);
	$stmt->execute();
	$stmt->close();
		return $stmt;
	}
?>