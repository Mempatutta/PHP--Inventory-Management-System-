<?php

	include('session.php');
	if(isset($_POST['plus'])){
		$id=mysqli_real_escape_string($conn,$_POST['id']);
		
		$query=mysqli_query($conn,"SELECT * FROM cart 
									WHERE product_ID='$id'");
		$row=mysqli_fetch_array($query);
		
		$newqty=$row['qty']+1;
		
		
	update_cart($conn,  $newqty, $id);}
	
	function update_cart($conn,$newqty, $id) {
		  
		$stmt = $conn->prepare("UPDATE cart 
								SET  qty=? 
								WHERE product_ID=?");
		$stmt->bind_param('ii', $newqty, $id);
		$stmt->execute();
		$stmt->close();
		
		return $stmt;
	}
	

?>