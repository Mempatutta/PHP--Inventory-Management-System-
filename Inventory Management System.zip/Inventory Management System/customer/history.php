
<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>

<script src="methods.js"></script>
<div class="container">
	<?php include('myCart_popUp.php'); ?>
	<div style="height: 50px;"></div>
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Purchase History</h1>
        </div>
    </div>
                <!-- /.row -->
				<div class="row">
                <div class="col-lg-12">
					<table width="100%" class="table table-striped table-bordered table-hover" id="historyTable">
						<thead>
							<tr>
								<th class="hidden"></th>
								<th>Purchase Date</th>
								<th>Total Amount</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
								$a=mysqli_query($conn,"SELECT * FROM sales
								WHERE user_ID='".$_SESSION['id']."' 
								ORDER BY sales_date DESC");
								while($row=mysqli_fetch_array($a)){
									?>
										<tr>
											<td class="hidden"></td>
											<td><?php echo date("M d, Y - h:i A", strtotime($row['sales_date']));?></td>
											<td><?php echo number_format($row['sales_total'],2); ?></td>
											<td>
												<a href="#detail<?php echo $row['sales_ID']; ?>" 
												data-toggle="modal" class="btn btn-primary btn-sm">
												<span class="glyphicon glyphicon-fullscreen">
												</span> View Full Details</a>
												<?php include ('modal_history.php'); ?>
											</td>
										</tr>
									<?php
								}
							?>
						</tbody>
                    </table>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
	
	
</div>

<script>
$(document).ready(function(){
	$('#history').addClass('active');
	
	$('#historyTable').DataTable({
	"bLengthChange": true,
	"bInfo": true,
	"bPaginate": true,
	"bFilter": true,
	"bSort": true,
	"pageLength": 10
	});
});
</script>
</body>
</html>