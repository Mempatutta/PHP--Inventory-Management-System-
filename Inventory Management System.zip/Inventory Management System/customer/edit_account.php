<?php
	include('session.php');
	
	$first_pswd=mysqli_real_escape_string($conn,sha1($_POST['first_pswd']));
	$second_pswd=mysqli_real_escape_string($conn,sha1($_POST['second_pswd']));
	
	if($first_pswd!=$second_pswd){
		?>
		<script>
			window.alert('Both entered password not match. Password not saved!');
			window.history.back();
		</script>
		<?php
	}
	elseif($first_pswd!=$row['password']){
		?>
		<script>
			window.alert('Entered password and password on file not match. Password not saved!');
			window.history.back();
		</script>
		<?php
	}
	else{
		$username=mysqli_real_escape_string($conn,$_POST['username']);
		$password=mysqli_real_escape_string($conn,$_POST['password']);
		
		$password==$row['password']?$new_pswd=$password:$new_pswd=sha1($password);
		}

	edit_account($conn,$username, $new_pswd);
	function edit_account($conn,$username, $new_pswd) {
		  
		$stmt = $conn->prepare("UPDATE user 
							SET username=?, password=?
							WHERE user_ID=?");
		$stmt->bind_param('ssi', $username, $new_pswd,$_SESSION['id'] );
		$stmt->execute();
		$stmt->close();
		return $stmt;
	}
		?>
		<script>
			window.alert('Success, password saved!');
			window.history.back();
		</script>
		<?php
	
		
?>