<!-- Add Product -->
    <div class="modal fade" id="addproduct" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Add New Product</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
                    <form role="form" method="POST" action="add_product.php" enctype="multipart/form-data">
						<div class="container-fluid">
						<div style="height:20px;"></div>
						<div class="form-group input-group">
                            <span style="width:200px;" class="input-group-addon">Name:</span>
                            <input type="text" style="width:300px; text-transform:capitalize;" class="form-control" name="name" required>
                        </div>
						<div class="form-group input-group">
                            <span style="width:200px;" class="input-group-addon">Category:</span>
                            <select style="width:300px;" class="form-control" name="category">
								<?php
									$category=mysqli_query($conn,"SELECT * FROM category");
									while($row=mysqli_fetch_array($category)){
										?>
											<option value="<?php echo $row['category_ID']; ?>"><?php echo $row['category_name']; ?></option>
										<?php
									}
								?>
							</select>
                        </div>
                        <div class="form-group input-group">
                            <span style="width:200px;" class="input-group-addon">Price:</span>
                            <input type="text" style="width:300px;" class="form-control" name="price" required>
                        </div>
						<div class="form-group input-group">
                            <span style="width:200px;" class="input-group-addon">Quantity:</span>
                            <input type="text" style="width:300px;" class="form-control" name="qty">
                        </div>
						<div class="form-group input-group">
                            <span style="width:200px;" class="input-group-addon">Photo:</span>
                            <input type="file" style="width:300px;" class="form-control" name="image">
                        </div>            
						</div>
				</div>
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
					</form>
                </div>
			</div>
		</div>
    </div>
<!-- /.modal -->

