<?php

	include('session.php');
	$user_ID=mysqli_real_escape_string($conn, $_GET['id']);

	$name= mysqli_real_escape_string($conn,$_POST['name']);
	$address=mysqli_real_escape_string($conn, $_POST['address']);
	$contact= mysqli_real_escape_string($conn,$_POST['contact']);
	
	//custom function to edit_profile
	edit_profile($conn,$name, $address, $contact, $user_ID);
	function edit_profile($conn,$name, $address, $contact, $user_ID) {
		  
		$stmt = $conn->prepare("UPDATE supplier 
	 SET supplier_name=?, address=?, contact=? 
	 WHERE user_ID=?");
    $stmt->bind_param('sssi', $name, $address, $contact, $user_ID);
    $stmt->execute();
	$stmt->close();
		return $stmt;
	}
	?>
		<script>
			window.alert('Success, profile saved!');
			window.history.back();
		</script>
	<?php
	
?>