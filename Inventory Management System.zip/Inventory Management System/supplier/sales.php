<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
<?php include('modal_add.php'); ?>
<script src="methods.js"></script>
<div class="container">
<div style="height:50px;"></div>
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Sales Report</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <table width="100%" class="table table-striped table-bordered table-hover" id="prodTable">
                <thead>
                    <tr>
						<th class="hidden"></th>
                        <th>Purchase Date</th>
                        <th>Customer</th>
						<th>Product Name</th>
						<th>Quantity</th>
                    </tr>
                </thead>
                <tbody>
				<?php
					$sales=mysqli_query($conn,"SELECT * FROM sales_detail 
					JOIN product ON product.product_ID=sales_detail.product_ID  
					JOIN sales ON sales.sales_ID=sales_detail.sales_ID 
					JOIN customer ON sales.user_ID=customer.user_ID 
					WHERE product.supplier_ID='".$_SESSION['id']."' 
					ORDER BY sales.sales_date DESC");
					while($row=mysqli_fetch_array($sales)){
						
					?>
						<tr>
							<td class="hidden"></td>
							<td><?php echo date('M d, Y h:i A',strtotime($row['sales_date'])); ?></td>
							<td><?php echo $row['customer_name']; ?></td>
							<td><?php echo $row['product_name']; ?></td>
							<td><?php echo $row['sales_qty']; ?></td>
						</tr>
					<?php
					}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>