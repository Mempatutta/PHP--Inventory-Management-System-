<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<?php include('navbar.php'); ?>
<?php include('css.php'); ?>
<?php include('modal.php'); ?>
<?php include('modal_add.php'); ?>
<script src="methods.js"></script>
<div class="container">

<div style="height:50px;"></div>
<p> Welcome, supplier.</p>
<p> Your user ID is <?php echo $_SESSION['id']; ?> </p>
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Products
				<span class="pull-right">
					<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addproduct"><i class="fa fa-plus-circle"></i> Add Product</button>
				</span>
			</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <table width="100%" class="table table-striped table-bordered table-hover" id="prodTable">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Price</th>
						<th>Quantity</th>
						<th>Photo</th>
						<th>Action</th>
                    </tr>
                </thead>
                <tbody>
				<?php
				//select product only those added by supplier or Admin. 
				//The supplierID must correspond categoryID, to edit/delete
					$prdct=mysqli_query($conn,"SELECT * FROM product 
												WHERE supplier_ID='".$_SESSION['id']."'");
					while($prdct_row=mysqli_fetch_array($prdct)){
						$product_id=$prdct_row['product_ID'];
					?>
						<tr>
							<td><?php print $prdct_row['product_name']; ?></td>
							<td><?php print $prdct_row['product_price']; ?></td>
							<td><?php print $prdct_row['product_qty']; ?></td>
							<td>
							<img src="../<?php 
							($prdct_row['picture'])?print $prdct_row['picture']:print "picture/noImage2.jpg"; 
							?>" height="40px" width="40px;"></td>

							
								
							<td>
								<button class="btn btn-success btn-sm" data-toggle="modal" data-target="#editprod_<?php print $product_id; ?>"><i class="fa fa-edit"></i> Edit</button>
								<button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delproduct_<?php print $product_id; ?>"><i class="fa fa-trash"></i> Delete</button>
								<?php include('modal_product.php'); ?>
							</td>
						</tr>
					<?php
					}
				?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>