<?php
	
	require_once('session.php');
	$id=mysqli_real_escape_string($conn,$_GET['id']);
	
	$prdct=mysqli_query($conn,"SELECT * FROM product 
								WHERE product_ID='$id'");
	$prdct_row=mysqli_fetch_array($prdct);
	
	$name=mysqli_real_escape_string($conn,$_POST['name']);
	$category=mysqli_real_escape_string($conn,$_POST['category']);
	$price=mysqli_real_escape_string($conn,$_POST['price']);
	$qty=mysqli_real_escape_string($conn,$_POST['qty']);
	
	$path = PATHINFO($_FILES["image"]["name"]);
	
	if (empty($_FILES["image"]["name"])){
		$location=$prdct_row['picture'];
	}
	else{
		if ($path['extension'] == "png" OR $path['extension'] == "jpg") {
			$newProduct = $path['filename'] . "_" . time() . "." . $path['extension'];
			move_uploaded_file($_FILES["image"]["tmp_name"], "../picture/" . $newProduct);
			$location = "picture/" . $newProduct;
		}
		else{
			$location=$prdct_row['picture'];
			?>
				<script>
					window.alert('Picture not edited!');
				</script>
			<?php
		}
	}
	
	edit_product($conn,$name, $category, $price, $location, $qty ,$id);
	function edit_product($conn,$name, $category, $price, 
								$location, $qty ,$id) {
		  
		$stmt = $conn->prepare("UPDATE product 
	 SET product_name=?, category_ID=?, product_price=?, 
	 picture=?, product_qty=? 
	 WHERE product_ID=?");
    $stmt->bind_param('sidsdi', $name, $category, $price, 
								$location, $qty ,$id);
    $stmt->execute();
	$stmt->close();
		return $stmt;
	}
	
	edit_inventory($conn, $ep, $id, $qty);
	function edit_inventory($conn,$ep, $id, $qty) {
		  
		$stmt = $conn->prepare("INSERT INTO inventory
	(user_ID ,action, product_ID, quantity, inventory_date) 
	VALUES (?,?,?,?,NOW())");
	$ep="Edit Product";
	
	$stmt->bind_param('isid',$_SESSION['id'], $ep, $id, $qty);

    $stmt->execute();
	$stmt->close();
		return $stmt;
	}
	?>
		<script>
			window.alert('Success, product updated!');
			window.history.back();
		</script>
	<?php

?>